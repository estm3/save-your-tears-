﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Markov
{
    public partial class frmMarkov : Form
    {
        public frmMarkov()
        {
            InitializeComponent();
        }

        private void btnContinuar_Click(object sender, EventArgs e)
        {
            if (txtEstados.Text != "")
            {
                int i, b = 0;
                b = Int32.Parse(txtEstados.Text);
                dgvRes.Columns.Add("col_inicio", "");
                for (i = 1; i <= b; i++)
                {
                    dgvStados.Rows.Add("S"+i+"");

                    dgvMatriz.Columns.Add("col_S" + i + "", "S" + i + "");//nombre,tex
                    dgvMatriz.Rows.Add();

                    dgvRes.Columns.Add("col_p(s" + i + ")", "P(s" + i + ")");//nombre,tex
                }
            }
        }

        private void btnPro_Click(object sender, EventArgs e)
        {
            if (txtEstados.Text != "")
            {
                int stados = Int32.Parse(txtEstados.Text);
                if (stados == 2 && txtDias.Text != "")
                {
                    dos_estados();
                }
                if (stados == 3 && txtDias.Text != "")
                {
                    tres_estados();
                }
                if (stados == 4 && txtDias.Text != "")
                {
                    cuatro_estados();
                }
            }
        }
        //FUNCIONES PARA LOS ESTADOS
        private void dos_estados()
        {
            decimal aux1 = 0, aux2 = 0;
            int dias = Int32.Parse(txtDias.Text);
            decimal res = 0, s1 = 0, s2 = 0, p11 = 0, p21 = 0;
            int b = 0, v = 0, i = 1;
            foreach (DataGridViewRow row in dgvStados.Rows)
            {
                if (b == 0)
                {
                    s1 = Convert.ToDecimal(row.Cells["col_pro"].Value);
                    aux1 = s1;
                    b = 1;
                }
                else
                {
                    s2 = Convert.ToDecimal(row.Cells["col_pro"].Value);
                    aux2 = s2;
                }
                if (v == 0)
                {
                    foreach (DataGridViewRow ros in dgvMatriz.Rows)
                    {
                        if (b == 1)
                        {
                            p11 = Convert.ToDecimal(ros.Cells["col_S1"].Value);
                            b = 2;
                        }
                        else
                        {
                            p21 = Convert.ToDecimal(ros.Cells["col_S1"].Value);
                        }
                    }
                    v = 1;
                }
            }
            int x = 0;
            while (i <= dias)
            {
                decimal ps = s1 * p11 + s2 * p21;
                res = 1 - ps;
                ps = Math.Round(ps, 3);
                res = Math.Round(res, 3);
                if (x == 0)
                {
                    dgvRes.Rows.Add("Inicio", aux1, aux2);
                    x = 1;
                }
                dgvRes.Rows.Add(i,ps, res);
                s1 = ps;
                s2 = res;
                i++;
            }
        }

        private void tres_estados()
        {
            int dias = Int32.Parse(txtDias.Text);
            decimal aux1 = 0, aux2 = 0, aux3 = 0;
            decimal s1 = 0, s2 = 0, s3 = 0;
            decimal p11 = 0, p21 = 0, p31 = 0;
            decimal p12 = 0, p22 = 0, p32 = 0;
            decimal p13 = 0, p23 = 0, p33 = 0;
            int b = 0, bb = 0, v = 0, i = 1;
            foreach (DataGridViewRow row in dgvStados.Rows)
            {
                if (b == 0)
                {
                    s1 = Convert.ToDecimal(row.Cells["col_pro"].Value);
                    aux1 = s1;
                }
                if (b == 1)
                {
                    s2 = Convert.ToDecimal(row.Cells["col_pro"].Value);
                    aux2 = s2;
                }
                if (b == 2)
                {
                    s3 = Convert.ToDecimal(row.Cells["col_pro"].Value);
                    aux3 = s3;
                }

                if (v == 0)
                {
                    foreach (DataGridViewRow ros in dgvMatriz.Rows)
                    {
                        if (bb == 0)
                        {
                            p11 = Convert.ToDecimal(ros.Cells["col_S1"].Value);
                            p12 = Convert.ToDecimal(ros.Cells["col_S2"].Value);
                            p13 = Convert.ToDecimal(ros.Cells["col_S3"].Value);
                        }
                        if (bb == 1)
                        {
                            p21 = Convert.ToDecimal(ros.Cells["col_S1"].Value);
                            p22 = Convert.ToDecimal(ros.Cells["col_S2"].Value);
                            p23 = Convert.ToDecimal(ros.Cells["col_S3"].Value);
                        }
                        if (bb == 2)
                        {
                            p31 = Convert.ToDecimal(ros.Cells["col_S1"].Value);
                            p32 = Convert.ToDecimal(ros.Cells["col_S2"].Value);
                            p33 = Convert.ToDecimal(ros.Cells["col_S3"].Value);
                        }
                        bb++;
                    }
                    v = 1;
                }
                b++;
            }
            int x = 0;
            while (i <= dias)
            {
                decimal rs1 = s1 * p11 + s2 * p21 + s3 * p31;
                decimal rs2 = s1 * p12 + s2 * p22 + s3 * p32;
                decimal rs3 = s1 * p13 + s2 * p23 + s3 * p33;
                rs1 = Math.Round(rs1, 3);
                rs2 = Math.Round(rs2, 3);
                rs3 = Math.Round(rs3, 3);
                if (x == 0)
                {
                    dgvRes.Rows.Add("Inicio", aux1, aux2, aux3);
                    x = 1;
                }
                dgvRes.Rows.Add(i, rs1, rs2, rs3);
                s1 = rs1;
                s2 = rs2;
                s3 = rs3;
                i++;
            }
        }

        private void cuatro_estados()
        {
            int dias = Int32.Parse(txtDias.Text);

            decimal aux1 = 0, aux2 = 0, aux3 = 0, aux4 = 0;
            decimal s1 = 0, s2 = 0, s3 = 0, s4 = 0;
            decimal p11 = 0, p21 = 0, p31 = 0, p41 = 0;
            decimal p12 = 0, p22 = 0, p32 = 0, p42 = 0;
            decimal p13 = 0, p23 = 0, p33 = 0, p43 = 0;
            decimal p14 = 0, p24 = 0, p34 = 0, p44 = 0;
            int b = 0, bb = 0, v = 0, i = 1;
            foreach (DataGridViewRow row in dgvStados.Rows)
            {
                if (b == 0)
                {
                    s1 = Convert.ToDecimal(row.Cells["col_pro"].Value);
                    aux1 = s1;
                }
                if (b == 1)
                {
                    s2 = Convert.ToDecimal(row.Cells["col_pro"].Value);
                    aux2 = s2;
                }
                if (b == 2)
                {
                    s3 = Convert.ToDecimal(row.Cells["col_pro"].Value);
                    aux3 = s3;
                }
                if (b == 3)
                {
                    s4 = Convert.ToDecimal(row.Cells["col_pro"].Value);
                    aux4 = s4;
                }
                if (v == 0)//para que solo una vez entre y no tarde mucho
                {
                    foreach (DataGridViewRow ros in dgvMatriz.Rows)
                    {
                        if (bb == 0)
                        {
                            p11 = Convert.ToDecimal(ros.Cells["col_S1"].Value);
                            p12 = Convert.ToDecimal(ros.Cells["col_S2"].Value);
                            p13 = Convert.ToDecimal(ros.Cells["col_S3"].Value);
                            p14 = Convert.ToDecimal(ros.Cells["col_S4"].Value);
                        }
                        if (bb == 1)
                        {
                            p21 = Convert.ToDecimal(ros.Cells["col_S1"].Value);
                            p22 = Convert.ToDecimal(ros.Cells["col_S2"].Value);
                            p23 = Convert.ToDecimal(ros.Cells["col_S3"].Value);
                            p24 = Convert.ToDecimal(ros.Cells["col_S4"].Value);
                        }
                        if (bb == 2)
                        {
                            p31 = Convert.ToDecimal(ros.Cells["col_S1"].Value);
                            p32 = Convert.ToDecimal(ros.Cells["col_S2"].Value);
                            p33 = Convert.ToDecimal(ros.Cells["col_S3"].Value);
                            p34 = Convert.ToDecimal(ros.Cells["col_S4"].Value);
                        }
                        if (bb == 3)
                        {
                            p41 = Convert.ToDecimal(ros.Cells["col_S1"].Value);
                            p42 = Convert.ToDecimal(ros.Cells["col_S2"].Value);
                            p43 = Convert.ToDecimal(ros.Cells["col_S3"].Value);
                            p44 = Convert.ToDecimal(ros.Cells["col_S4"].Value);
                        }
                        bb++;
                    }
                    v = 1;
                }
                b++;
            }
            int x = 0;
            while (i <= dias)
            {
                decimal rs1 = s1 * p11 + s2 * p21 + s3 * p31 + s4 * p41;
                decimal rs2 = s1 * p12 + s2 * p22 + s3 * p32 + s4 * p42;
                decimal rs3 = s1 * p13 + s2 * p23 + s3 * p33 + s4 * p43;
                decimal rs4 = s1 * p14 + s2 * p24 + s3 * p34 + s4 * p44;
                rs1 = Math.Round(rs1, 3);
                rs2 = Math.Round(rs2, 3);
                rs3 = Math.Round(rs3, 3);
                rs4 = Math.Round(rs4, 3);
                if (x == 0)
                {
                    dgvRes.Rows.Add("Inicio", aux1, aux2, aux3, aux4);
                    x = 1;
                }
                dgvRes.Rows.Add(i, rs1, rs2, rs3, rs4);
                s1 = rs1;
                s2 = rs2;
                s3 = rs3;
                s4 = rs4;
                i++;
            }
        }

        private void cinco_estados()
        {
            //faltante
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnnuevo_Click(object sender, EventArgs e)
        {
            txtEstados.Enabled = true;
            txtEstados.Text = "";
            btnContinuar.Enabled = true;
            dgvMatriz.Rows.Clear();
            dgvStados.Rows.Clear();
            dgvRes.Rows.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 regresar = new Form2();
            regresar.Show();
            this.Hide();
        }
    }
}
