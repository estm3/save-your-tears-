﻿Public Class Form1
     



    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)


    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        a.Text = ""
        u.Text = ""
        Label5.Text = ""
        TextBox1.Text = ""



    End Sub

    Private Sub a_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles a.Click

    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles a.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            SendKeys.Send("{TAB}")
        End If
        If InStr(1, "0123456789,-" & Chr(8), e.KeyChar) = 0 Then
            e.KeyChar = ""
        End If

    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a.TextChanged





    End Sub

    Private Sub u_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles u.Click


    End Sub

    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles u.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            SendKeys.Send("{TAB}")
        End If
        If InStr(1, "0123456789,-" & Chr(8), e.KeyChar) = 0 Then
            e.KeyChar = ""
        End If

    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles u.TextChanged


    End Sub

    Private Sub OPERACION_Click(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub OPERACION_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ComboBox1.Items.Add("TODAS LAS OPERACIONES:")
        ComboBox1.Items.Add("PROBABILIDAD DE HALLAR UN SISTEMA OCUPADO (P): ")
        ComboBox1.Items.Add("PROBABILIDAD DE HALLAR EL  SISTEMA VACIO U OCIOSO (PO):")
        ComboBox1.Items.Add("NUMERO ESPERANDO EN LA COLA (LQ):")
        ComboBox1.Items.Add("NUMERO ESPERANDO EN EL SISTEMA (L):")
        ComboBox1.Items.Add("TIEMPO ESPERADO EN LA COLA (WQ):")
        ComboBox1.Items.Add("TIEMPO ESPERADO EN EL SISTEMA(W):")
        


    End Sub


    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If MessageBox.Show("¿Desea Salir?", "Sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = DialogResult.No Then


        End If
        Me.Close()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Label5.Text = (ComboBox1.SelectedItem)
        Dim W As Double
        Dim WQ As Double

        Dim p As Double
        Dim po As Double
        Dim l As Double
        Dim lq As Double
        Dim valor1 As Double
        

        Dim valor2 As Double

        valor1 = a.Text
        valor2 = u.Text

        If ComboBox1.SelectedItem = "PROBABILIDAD DE HALLAR UN SISTEMA OCUPADO (P): " Then

            p = valor1 / valor2
            TextBox1.Text = p
        Else
            If ComboBox1.SelectedItem = "PROBABILIDAD DE HALLAR EL  SISTEMA VACIO U OCIOSO (PO): " Then

                po = 1 - (valor1 / valor2)
                TextBox1.Text = po
            Else
                If ComboBox1.SelectedItem = "NUMERO ESPERANDO EN LA COLA (LQ):" Then

                    lq = Val(valor1 * valor1) / Val(valor2 * (valor2 - valor1))
                    TextBox1.Text = lq
                Else

                    If ComboBox1.SelectedItem = "NUMERO ESPERANDO EN EL SISTEMA (L):" Then

                        l = 1 / (valor2 - valor1)
                        TextBox1.Text = l
                    Else
                        If ComboBox1.SelectedItem = "TIEMPO ESPERADO EN LA COLA (WQ):" Then

                            WQ = lq / valor2
                            TextBox1.Text = WQ
                        Else
                            If ComboBox1.SelectedItem = "TIEMPO ESPERADO EN EL SISTEMA(W):" Then

                                W = 1 / (valor2 - valor1)

                                TextBox1.Text = W
                            Else
                                If ComboBox1.SelectedItem = "TODAS LAS OPERACIONES:" Then
                                    Me.Hide()

                                    RESULTADO.Show()
                                    p = valor1 / valor2
                                    RESULTADO.TextBox1.Text = p






                                    po = 1 - (valor1 / valor2)
                                    RESULTADO.TextBox2.Text = po






                                    lq = Val(valor1 * valor1) / Val(valor2 * (valor2 - valor1))
                                    RESULTADO.TextBox3.Text = lq






                                    l = 1 / (valor2 - valor1)

                                    RESULTADO.TextBox4.Text = l



                                    WQ = lq / valor2
                                    RESULTADO.TextBox5.Text = WQ


                                    W = 1 / (valor2 - valor1)

                                    RESULTADO.textbox6.Text = W







                                End If


                            End If
                        End If
                    End If
                End If
            End If


        End If

    End Sub
End Class
