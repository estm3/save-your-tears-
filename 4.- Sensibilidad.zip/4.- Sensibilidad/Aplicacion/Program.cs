using System;
using System.Collections.Generic;
using System.Text;

namespace Aplicacion
{
    class Simplex
    {
        public static double m1 = 15;
        public static double n1 = 16;
        public static double epsilon = 0.0001;
        public static double[,] matriz;
        public static double[,] a;
        public static int j, m, n, clase, fase, t;
        public static double[] v;
        public static char resultado;
        
        public static void leer()        
        {
            

            a = new double[100, 100];
            v = new double[100];
            matriz = new double[100, 100];
            double temp;
            int i, j;
            //Console.ForegroundColor = ConsoleColor.Blue;
            //Console.BackgroundColor = ConsoleColor.White;
            
            Console.Write("Elige una opci�n:\n\n1=Max \n\n2=Min \n");
            clase = int.Parse(Console.ReadLine());
            if (clase == 2) clase = -1;
            Console.Write("Restricciones: ");
            m = int.Parse(Console.ReadLine());
            Console.Write("Variables: ");
            n = int.Parse(Console.ReadLine());
            Console.WriteLine("Coeficientes de la funcion objetivo: ");
            for (j = 1; j <= n; j++)
            {
                Console.Write("Numero {0}: ", j);
                a[m + 1, j] = double.Parse(Console.ReadLine());
            }
            Console.WriteLine();
            Console.WriteLine("Evaluar funci�n");
            Console.Write("Z = ");
            for (j = 1; j <= n; j++)
            {
                Console.Write("+ ({0})X({1}) ", a[m + 1, j],j);
            }
            Console.WriteLine();
            a[m + 1, n + 1] = 0;
            for (i = 1; i <= m; i++)
            {
                Console.WriteLine();
                Console.WriteLine("Restriccion # {0} coeficiente y constante: ",i);
                for (j = 1; j <= n + 1; j++)
                {
                    Console.Write("Numero ({0},{1}): ",i,j);
                    a[i, j] = double.Parse(Console.ReadLine());
                }
            }
            imprimirmatriz(ref a, m, n + 1);
            Console.WriteLine();
            for (i = 1; i <= m + 1; i++)
            {
                a[i, 0] = a[i, n + 1];
                v[i] = n + i;
            }
            for (j = 0; j <= n; j++)
            {
                temp = 0;
                a[m + 1, j] = clase * a[m + 1, j];
                for (i = 1; i <= m; i++) temp = temp + a[i, j];
                a[m + 2, j] = temp;
            }
            for (i = 1; i <= m + 2; i++)
            {
                for (j = n + 1; j <= m + n; j++)
                {
                    if (j == i + n)
                    {
                        a[i, j] = 1;
                    }
                    else
                    {
                        a[i, j] = 0;
                    }
                }
            }
        }
        
        public static void optimo(ref int lim,ref bool continuar,ref int piv)
        {
            t = 0;
            do
            {
                t = t + 1;
            } while (a[m + 2, t] <= 0 & t != lim);
            if ((t == lim) & a[m + 2, lim] <= 0)
            {
                resultado = '0';
                continuar = false;
            }
        }
        public static void diverge(ref int lim, ref bool continuar, ref int piv)
        {
            int i;
            i = 0;
            do
            {
                i++;
            } while ((a[i, t] <= 0) & (i != m));
            if ((i == m) & a[m, t] <= 0)
            {
                resultado = 'd';
                continuar = false;
            }
        }
        public static void razon(ref int lim, ref bool continuar, ref int piv)
        {
            int i, j;
            double r = 0, temp;
            j = 0;
            for (i = 1; i <= m; i++)
            {
                if (a[i, t] > 0)
                {
                    temp = a[i, 0] / a[i, t];
                    j = j + 1;
                    if (j == 1)
                    {
                        r = temp;
                        piv = i;
                    }
                    else
                    {
                        if (r > temp)
                        {
                            r = temp;
                            piv = i;
                        }
                    }
                }
            }
            v[piv] = t;
        }
        public static void arreglar(ref int lim, ref bool continuar, ref int piv)
        {
            int i, j;
            double d;
            d = a[piv, t];
            for (j = 0; j <= lim; j++)
            {
                a[piv, j] = a[piv, j] / d;
            }
            for (i = 1; i <= m + 2; i++)
            {
                if (i != piv)
                {
                    for (j = 0; j <= lim; j++)
                        if (j != t)
                            a[i, j] = a[i, j] - a[i, t] * a[piv, j];
                    a[i, t] = 0;
                }
            }
        }
        public static void simplex()
        {
            int lim;
            bool continuar;
            int u, piv = 0;
            if (fase == 1)
            {
                lim = m + n;
                u = 1;
            }
            else
            {
                lim = n;
                u = -clase;
            }
            continuar = true;
            while (continuar)
            {
                optimo(ref lim, ref continuar, ref piv);
                if (continuar)
                {
                    diverge(ref lim, ref continuar, ref piv);
                }
                if (continuar)
                {
                    razon(ref lim, ref continuar, ref piv);
                    arreglar(ref lim, ref continuar, ref piv);
                }
            }
        }
        public static void imprimir()
        {
            int i;
            Console.WriteLine();
            if (resultado == '0')
            {
                Console.WriteLine("Valor optimo= " + (-1 * clase * a[m + 2, 0]));
                Console.WriteLine("Posible solucion optima es: ");
                for (i = 1; i <= m; i++)
                {
                    Console.WriteLine("X(" + v[i] + ")=" + a[i, 0]);
                }
                Console.WriteLine("Y X(i)=0 PARA VARIABLES (s1,s2,s3...sn)");
            }
            else
            {
                Console.WriteLine("Error al tratar de resolver");
                
                for (i = 1; i <= m; i++)
                {
                    Console.WriteLine("X(" + v[i] + ")=" + (-1 * a[i, t]) + "*T" + a[i, 0]);
                }
            }
        }
        public static void imprimirmatriz(ref double[,] s,int m,int n)
        {

            Console.Write("                         ");
            for (int h = 1; h <= n; h++)
            {
                
                Console.Write("\tX({0})", h);
            }
            Console.WriteLine();
            for (int i = 1; i <= m; i++)
            {
                Console.Write("Restriccion #{0},coef y const: ",i);
                for (int k = 1; k <= n; k++)
                {
                    Console.Write("\t{0}", s[i, k]);
                }
                Console.WriteLine();
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine();
            Console.WriteLine("An�lisis de Sensibilidad");
            Console.WriteLine();
            a = new double[100, 100];
            v = new double[100];
            leer();
            fase = 1;
            simplex();
            if (Math.Abs(a[m + 2, 0]) > epsilon)
            {
                Console.WriteLine("La funci�n no tiene soluci�n");
            }
            else
            {
                fase = 2;
                for (j = 0; j <= n; j++)
                {
                    a[m + 2, j] = a[m + 1, j];
                }
                simplex();
                imprimir();
            }
            Console.ReadLine();
        }
    }
}
